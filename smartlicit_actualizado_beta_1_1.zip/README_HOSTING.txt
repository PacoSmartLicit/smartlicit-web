SMARTLICIT · PAQUETE ESTÁTICO PARA HOSTING

Estructura generada desde el master unificado smartlicit_unificado_navegable.html.

Archivos principales:
- index.html: Home / página inicial.
- tender.html: Smart Tender.
- pricing.html: Smart Pricing.
- file.html: Smart File.
- lex.html: Smart Lex.
- tender-gov.html: Tender Gov.
- pricing-gov.html: Pricing Gov.
- membresias.html: Membresías.
- blog.html: Blog.
- ipg.html: IPG.
- efile.html: eFile.
- mi-cuenta.html: Mi Cuenta.
- gDrive.html: G-Drive Workspace.

Carpetas necesarias:
- assets/css/site-shell.css: estilos del header global y shell navegable.
- assets/js/site-shell.js: navegación, estado activo, menú móvil, modo offline/online y carga de secciones.
- sections/: contiene las secciones originales y las pantallas complementarias agregadas para navegación.

Cómo subirlo:
1. Sube todo el contenido de esta carpeta al directorio público del hosting, por ejemplo public_html/.
2. Asegúrate de que index.html quede en la raíz del sitio.
3. No muevas assets/ ni sections/, porque los HTML principales dependen de esas rutas.
4. En hosting, abre el dominio y navega desde el header.

Prueba local recomendada:
Desde la carpeta del sitio ejecuta:
python3 -m http.server 8000
Luego abre http://localhost:8000/

Notas:
- Se incluyeron aliases de compatibilidad: home.html, smart-tender.html, smart-pricing.html, smart-file.html, smart-lex.html, membresia.html, micuenta.html y gdrive.html.
- El menú "G-Drive Workspace" lleva a gDrive.html.
- Las secciones originales permanecen en /sections para conservar el contenido del master.

ACTUALIZACIÓN · FLUJO OFFLINE / ONLINE Y PANTALLAS COMPLEMENTARIAS

Archivos agregados o activados para esta iteración:
- sections/offline-solution.html: pantalla pública offline reusable para Tender, Pricing, File, Lex, Tender Gov y Pricing Gov.
- sections/ipg-offline.html: pantalla offline de IPG con bloqueo de consultas hasta registro/login.
- sections/tender-ai-thirds.html: interfaz en tercios para Smart Tender · Propuesta IA.
- sections/lex-ai-thirds.html: interfaz en tercios para Smart Lex · Asistente IA.
- tender-ai.html: shell navegable para la interfaz en tercios de Smart Tender.
- lex-ai.html: shell navegable para la interfaz en tercios de Smart Lex.
- assets/css/flow-screens.css y assets/js/flow-screens.js: estilos y lógica de pantallas offline/tercios.
- CANVA_PROMPT_FLUJO_PANTALLAS_SMARTLICIT.txt: prompt maestro para crear el flujo de pantallas en Canva.
- CHANGELOG_FLUJO_OFFLINE_ONLINE.txt: resumen de cambios aplicados.

Reglas implementadas:
- El sitio inicia en modo offline si no existe sesión demo guardada en localStorage.
- Las páginas de soluciones cargan pantalla pública offline y, al activar modo online, cargan el dashboard actual sin reescribirlo.
- IPG en offline muestra bloqueo/registro antes de consultas y filtros.
- Smart Tender online redirige Propuesta IA a tender-ai.html.
- Smart Lex online redirige acciones de asistente/generar escrito a lex-ai.html.
- El add-on de WhatsApp aparece como combo en las membresías donde aplica.
