(function(){
  const body = document.body;
  const current = body.dataset.page || 'home';
  const flow = body.dataset.flow || '';
  const iframe = document.getElementById('slxFrame');
  const loader = document.getElementById('slxLoader');
  const siteNav = document.getElementById('slxSiteNav');
  const mobileToggle = document.getElementById('slxMobileToggle');
  const accountWrap = document.getElementById('slxAccountWrap');
  const accountTrigger = document.getElementById('slxAccountTrigger');
  const toast = document.getElementById('slxToast');
  const pageFileMap = {
    'home':'index.html',
    'smart-tender':'tender.html',
    'smart-pricing':'pricing.html',
    'smart-file':'file.html',
    'smart-lex':'lex.html',
    'tender-gov':'tender-gov.html',
    'pricing-gov':'pricing-gov.html',
    'membresias':'membresias.html',
    'blog':'blog.html',
    'ipg':'ipg.html',
    'efile':'efile.html',
    'micuenta':'mi-cuenta.html',
    'gdrive':'gDrive.html'
  };
  const gatedOfflineMap = {
    'smart-tender':'sections/offline-solution.html?solution=tender',
    'smart-pricing':'sections/offline-solution.html?solution=pricing',
    'smart-file':'sections/offline-solution.html?solution=file',
    'smart-lex':'sections/offline-solution.html?solution=lex',
    'tender-gov':'sections/offline-solution.html?solution=tenderGov',
    'pricing-gov':'sections/offline-solution.html?solution=pricingGov',
    'ipg':'sections/ipg-offline.html'
  };
  const oldFileMap = {
    'Home.html':'../index.html', 'home.html':'../index.html', 'index.html':'../index.html',
    'Membresia.html':'../membresias.html', 'membresia.html':'../membresias.html', 'membresias.html':'../membresias.html',
    'blog.html':'../blog.html', 'ipg.html':'../ipg.html', 'eFile.html':'../efile.html', 'efile.html':'../efile.html',
    'micuenta.html':'../mi-cuenta.html', 'mi-cuenta.html':'../mi-cuenta.html',
    'gDrive.html':'../gDrive.html', 'gdrive.html':'../gDrive.html',
    'smart tender.html':'../tender.html', 'smart-tender.html':'../tender.html', 'tender.html':'../tender.html',
    'smart pricing.html':'../pricing.html', 'smart-pricing.html':'../pricing.html', 'pricing.html':'../pricing.html',
    'smart file.html':'../file.html', 'smart-file.html':'../file.html', 'file.html':'../file.html',
    'smart lex.html':'../lex.html', 'smart-lex.html':'../lex.html', 'lex.html':'../lex.html',
    'tender gov.html':'../tender-gov.html', 'tender-gov.html':'../tender-gov.html',
    'pricing gov.html':'../pricing-gov.html', 'pricing-gov.html':'../pricing-gov.html'
  };
  function showToast(msg){
    if(!toast) return;
    toast.textContent = msg || 'Vista cargada';
    toast.classList.add('active');
    clearTimeout(showToast._t);
    showToast._t = setTimeout(()=>toast.classList.remove('active'), 1800);
  }
  function queryMode(){
    const params = new URLSearchParams(window.location.search);
    if(params.get('online') === '1' || params.get('mode') === 'online') return 'online';
    if(params.get('offline') === '1' || params.get('mode') === 'offline') return 'offline';
    return null;
  }
  function getMode(){
    const fromQuery = queryMode();
    if(fromQuery){
      try{ localStorage.setItem('slxAuthMode', fromQuery); }catch(e){}
      return fromQuery;
    }
    try{ return localStorage.getItem('slxAuthMode') || 'offline'; }catch(e){ return 'offline'; }
  }
  function isOnline(){ return getMode() === 'online'; }
  function setMode(mode, redirect){
    const next = mode === 'offline' ? 'offline' : 'online';
    try{ localStorage.setItem('slxAuthMode', next); }catch(e){}
    updateAuthControl();
    updateDriveControl();
    if(redirect){
      window.location.href = redirect;
      return;
    }
    if(flow && next === 'offline' && pageFileMap[current]){
      window.location.href = pageFileMap[current];
      return;
    }
    if(iframe) loadFrame();
    showToast(next === 'online' ? 'Modo online activo' : 'Modo offline activo');
  }
  const driveFolders = {
    'home':'/SmartLicit/Home',
    'smart-tender':'/SmartLicit/Tender/Guantes de nitrilo',
    'smart-pricing':'/SmartLicit/Pricing/Guantes de nitrilo',
    'smart-file':'/SmartLicit/File/Expedientes',
    'smart-lex':'/SmartLicit/Lex/Amparo fiscal Grupo Atlas/Escritos',
    'tender-gov':'/SmartLicit/Tender Gov/Proyecto institucional',
    'pricing-gov':'/SmartLicit/Pricing Gov/Estudios institucionales',
    'membresias':'/SmartLicit/Membresias',
    'blog':'/SmartLicit/Blog',
    'ipg':'/SmartLicit/IPG',
    'efile':'/SmartLicit/eFile',
    'micuenta':'/SmartLicit/Mi Cuenta',
    'gdrive':'/SmartLicit/Workspace'
  };
  function currentDriveFolder(){ return driveFolders[current] || '/SmartLicit/Tender/Guantes de nitrilo'; }
  function ensureShellModal(){
    let modal = document.getElementById('slxShellModal');
    if(modal) return modal;
    modal = document.createElement('div');
    modal.id = 'slxShellModal';
    modal.className = 'slx-shell-modal';
    modal.setAttribute('role','dialog');
    modal.setAttribute('aria-modal','true');
    modal.innerHTML = '<div class="slx-shell-modal-card"><div class="slx-shell-modal-head"><div><h2 id="slxShellModalTitle">SmartLicit</h2><p id="slxShellModalText">Acción segura.</p></div><button class="slx-shell-modal-close" type="button" aria-label="Cerrar">×</button></div><div class="slx-shell-modal-body" id="slxShellModalBody"></div></div>';
    document.body.appendChild(modal);
    modal.addEventListener('click', e=>{ if(e.target === modal) closeShellModal(); });
    modal.querySelector('.slx-shell-modal-close').addEventListener('click', closeShellModal);
    return modal;
  }
  function closeShellModal(){
    const modal = document.getElementById('slxShellModal');
    if(modal) modal.classList.remove('open');
  }
  function openShellModal(opts){
    const modal = ensureShellModal();
    modal.querySelector('#slxShellModalTitle').textContent = (opts && opts.title) || 'SmartLicit';
    modal.querySelector('#slxShellModalText').textContent = (opts && opts.text) || '';
    modal.querySelector('#slxShellModalBody').innerHTML = (opts && opts.body) || '';
    modal.classList.add('open');
    return modal;
  }
  function showOnlineAuthModal(onAccept){
    const modal = openShellModal({
      title:'Autenticación segura requerida',
      text:'Confirma tu identidad para operar en modo online.',
      body:'<div class="slx-shell-modal-row"><span aria-hidden="true" style="font-size:22px">🔐</span><div><strong>Para operar en modo online, confirma tu identidad con código seguro o autenticación biométrica.</strong><span>Código enviado / Face ID / verificación biométrica.</span></div></div><div class="slx-shell-modal-actions"><button class="slx-shell-btn" type="button" data-slx-close>Cancelar</button><button class="slx-shell-btn primary" type="button" data-slx-confirm>Confirmar identidad</button></div>'
    });
    modal.querySelector('[data-slx-close]').addEventListener('click', closeShellModal);
    modal.querySelector('[data-slx-confirm]').addEventListener('click', ()=>{
      closeShellModal();
      if(typeof onAccept === 'function') onAccept();
    });
  }
  function installDriveControl(){
    if(!accountWrap || !accountWrap.parentElement || document.getElementById('slxDriveControl')) return;
    const drive = document.createElement('button');
    drive.type = 'button';
    drive.id = 'slxDriveControl';
    drive.className = 'slx-drive-control';
    drive.addEventListener('click', showDriveModal);
    const auth = document.getElementById('slxAuthMode');
    accountWrap.parentElement.insertBefore(drive, auth || accountWrap);
    updateDriveControl();
  }
  function updateDriveControl(){
    const drive = document.getElementById('slxDriveControl');
    if(!drive) return;
    const online = isOnline();
    drive.classList.toggle('disconnected', !online);
    if(online){
      drive.title = 'Cuenta conectada: rockyratapiedra@gmail.com';
      drive.innerHTML = '<img src="assets/img/google-drive.svg" alt="Google Drive"><span class="drive-detail"><strong>Drive activo</strong><span class="optional"> · rockyratapiedra@gmail.com · '+currentDriveFolder()+' · Sincronizado</span></span>';
    }else{
      drive.title = 'Conectar Google Drive';
      drive.innerHTML = '<img src="assets/img/google-drive.svg" alt="Google Drive"><span class="drive-detail"><strong>Conectar Google Drive</strong></span>';
    }
  }
  function showDriveModal(){
    const online = isOnline();
    const folder = currentDriveFolder();
    const modal = openShellModal({
      title: online ? 'Google Drive Workspace conectado' : 'Conectar Google Drive',
      text: online ? 'Autoguardado en Drive activo para esta sección.' : 'Ingresa credenciales de Gmail y confirma tu identidad para integrar Drive.',
      body:'<div class="slx-shell-modal-row"><img src="assets/img/google-drive.svg" alt="Google Drive"><div><strong>'+(online ? 'Drive activo' : 'Conectar Google Drive')+'</strong><span>'+(online ? 'Cuenta conectada: rockyratapiedra@gmail.com' : 'Antes de login: Conectar Google Drive')+'</span></div></div><div class="slx-shell-modal-row"><span aria-hidden="true" style="font-size:20px">📁</span><div><strong>Carpeta destino</strong><span>'+folder+'</span></div></div><div class="slx-shell-modal-row"><span aria-hidden="true" style="font-size:20px">✓</span><div><strong>Estado de sincronización</strong><span>'+(online ? 'Sincronizado · Autoguardado en Drive' : 'Pendiente de autenticación segura')+'</span></div></div><div class="slx-shell-modal-row"><span aria-hidden="true" style="font-size:20px">🔐</span><div><strong>Modo online seguro</strong><span>Para operar en modo online, confirma tu identidad con código seguro o autenticación biométrica.</span></div></div><div class="slx-shell-modal-actions"><button class="slx-shell-btn" type="button" data-slx-close>Cerrar</button><button class="slx-shell-btn efile" type="button" data-slx-drive-login>Ingresar credenciales de Gmail para integrar Drive</button></div>'
    });
    modal.querySelector('[data-slx-close]').addEventListener('click', closeShellModal);
    modal.querySelector('[data-slx-drive-login]').addEventListener('click', ()=>{
      if(online){
        showToast('Drive ya está activo · rockyratapiedra@gmail.com');
        closeShellModal();
      }else{
        closeShellModal();
        showOnlineAuthModal(()=>setMode('online'));
      }
    });
  }
  function patchEfileMenu(){
    document.querySelectorAll('.slx-account-menu a[data-page="efile"]').forEach(link=>{
      if(link.dataset.efileStyled) return;
      link.dataset.efileStyled = '1';
      link.classList.add('slx-efile-link');
      link.innerHTML = '<span class="efile-bolt" aria-hidden="true">⚡</span><span class="efile-word">eFile</span>';
    });
  }
  function toggleOnlineMode(){
    if(isOnline()){
      setMode('offline');
      return;
    }
    showOnlineAuthModal(()=>setMode('online'));
  }
  function installAuthControl(){
    if(!accountWrap || !accountWrap.parentElement || document.getElementById('slxAuthMode')) return;
    const control = document.createElement('button');
    control.type = 'button';
    control.id = 'slxAuthMode';
    control.className = 'slx-auth-control';
    control.addEventListener('click', toggleOnlineMode);
    accountWrap.parentElement.insertBefore(control, accountWrap);
    const menu = accountWrap.querySelector('.slx-account-menu');
    if(menu && !document.getElementById('slxAuthMenuAction')){
      const divider = document.createElement('div');
      divider.className = 'slx-account-divider';
      const action = document.createElement('a');
      action.href = '#';
      action.id = 'slxAuthMenuAction';
      action.setAttribute('role','menuitem');
      action.addEventListener('click', e=>{
        e.preventDefault();
        toggleOnlineMode();
      });
      menu.appendChild(divider);
      menu.appendChild(action);
    }
    updateAuthControl();
  }
  function updateAuthControl(){
    const control = document.getElementById('slxAuthMode');
    const action = document.getElementById('slxAuthMenuAction');
    const online = isOnline();
    body.dataset.authMode = online ? 'online' : 'offline';
    if(control){
      control.classList.toggle('online', online);
      control.innerHTML = online ? '<span></span>Modo online' : '<span></span>Modo offline';
      control.title = online ? 'Cambiar a modo offline' : 'Cambiar a modo online / simular login';
    }
    if(action) action.textContent = online ? 'Cambiar a modo offline' : 'Registrarse / iniciar sesión';
  }
  function activateNav(){
    document.querySelectorAll('[data-page]').forEach(a => {
      a.classList.toggle('active', a.dataset.page === current);
    });
    if(['micuenta','efile','gdrive'].includes(current) && accountTrigger){
      accountTrigger.classList.add(current === 'gdrive' ? 'gdrive-active' : 'active');
    }
    if(current === 'gdrive' && accountTrigger) accountTrigger.textContent = 'G-Drive Workspace ▾';
  }
  function chosenBaseSrc(){
    if(!iframe) return '';
    if(flow) return iframe.dataset.src;
    if(!isOnline() && iframe.dataset.offlineSrc) return iframe.dataset.offlineSrc;
    if(!isOnline() && gatedOfflineMap[current]) return gatedOfflineMap[current];
    return iframe.dataset.onlineSrc || iframe.dataset.src;
  }
  function frameSrc(){
    const base = chosenBaseSrc();
    const hash = window.location.hash || '';
    return base + hash;
  }
  function loadFrame(){
    if(!iframe) return;
    loader && loader.classList.add('active');
    iframe.src = frameSrc();
  }
  function redirectTop(url){
    if(!url) return;
    window.location.href = url;
  }
  function patchTenderProposalFlow(doc){
    return;
  }
  function patchLexAssistantFlow(doc){
    if(current !== 'smart-lex' || flow || !isOnline()) return;
    const triggers = new Set();
    doc.querySelectorAll('[data-project-tab="writing"]').forEach(el=>triggers.add(el));
    doc.querySelectorAll('button').forEach(btn=>{
      const txt = (btn.textContent || '').trim().toLowerCase();
      if(txt.includes('generar escrito') || txt.includes('abrir análisis') || txt === 'borrador' || txt === 'subsanar') triggers.add(btn);
    });
    triggers.forEach(btn=>{
      if(btn.dataset.slxFlowPatched) return;
      btn.dataset.slxFlowPatched = 'lex-ai';
      btn.title = 'Abrir interfaz en tercios de Smart Lex';
      btn.addEventListener('click', e=>{
        e.preventDefault();
        e.stopImmediatePropagation();
        redirectTop('lex-ai.html');
      }, true);
    });
  }
  function patchInnerLinks(){
    try{
      const doc = iframe.contentDocument;
      if(!doc) return;
      doc.querySelectorAll('a[href]').forEach(a=>{
        const raw = (a.getAttribute('href') || '').trim();
        const decoded = decodeURIComponent(raw);
        const file = decoded.split('/').pop().split('#')[0];
        const mapped = oldFileMap[decoded] || oldFileMap[file];
        if(mapped){
          a.setAttribute('target','_top');
          a.setAttribute('href', mapped + (decoded.includes('#') ? '#'+decoded.split('#').slice(1).join('#') : ''));
        }
      });
      patchTenderProposalFlow(doc);
      patchLexAssistantFlow(doc);
    }catch(e){}
  }
  if(mobileToggle){
    mobileToggle.addEventListener('click',()=> siteNav && siteNav.classList.toggle('open'));
  }
  if(accountTrigger){
    accountTrigger.addEventListener('click', (e)=>{
      e.preventDefault();
      const open = !accountWrap.classList.contains('open');
      accountWrap.classList.toggle('open', open);
      accountTrigger.setAttribute('aria-expanded', String(open));
    });
  }
  document.addEventListener('click',(e)=>{
    if(accountWrap && !accountWrap.contains(e.target)){
      accountWrap.classList.remove('open');
      accountTrigger && accountTrigger.setAttribute('aria-expanded','false');
    }
  });
  function normalizeTopHref(href){
    if(!href) return '';
    return String(href).replace(/^\.\.\//,'');
  }
  window.addEventListener('message', (event)=>{
    const data = event.data || {};
    if(data.type === 'slx-auth-mode'){
      setMode(data.mode, normalizeTopHref(data.redirect));
      return;
    }
    if(data.type === 'slx:set-auth'){
      setMode(data.state === 'offline' ? 'offline' : 'online', normalizeTopHref(data.href));
      return;
    }
    if(data.type === 'slx:navigate'){
      const href = normalizeTopHref(data.href);
      if(href) window.location.href = href;
    }
  });
  if(iframe){
    iframe.addEventListener('load',()=>{
      loader && loader.classList.remove('active');
      patchInnerLinks();
    });
    window.addEventListener('hashchange',()=>{
      iframe.src = frameSrc();
    });
    loadFrame();
  }
  installAuthControl();
  installDriveControl();
  patchEfileMenu();
  activateNav();
})();
