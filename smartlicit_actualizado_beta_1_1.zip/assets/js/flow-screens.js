(function(){
  function sendMode(mode, redirect){
    try{
      window.top.postMessage({type:'slx-auth-mode', mode:mode || 'online', redirect:redirect || null}, '*');
    }catch(e){
      try{ localStorage.setItem('slxAuthMode', mode || 'online'); }catch(err){}
      if(redirect) window.top.location.href = redirect;
    }
  }
  document.addEventListener('click', function(e){
    const login = e.target.closest('[data-slx-login]');
    if(login){
      e.preventDefault();
      const redirect = login.getAttribute('data-redirect') || null;
      sendMode('online', redirect);
      return;
    }
    const offline = e.target.closest('[data-slx-offline]');
    if(offline){
      e.preventDefault();
      const redirect = offline.getAttribute('data-redirect') || null;
      sendMode('offline', redirect);
    }
  });
})();
